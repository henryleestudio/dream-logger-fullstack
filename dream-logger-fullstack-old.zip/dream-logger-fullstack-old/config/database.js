// config/database.js
module.exports = {

    'url' : 'mongodb+srv://mongo:mon123@cluster0.ayjrt.mongodb.net/dreamData?retryWrites=true&w=majority', 
    'dbName': 'dreamData'
};

